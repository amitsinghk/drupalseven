How to install

1. Use git (recommended because pdf.js is under active development) to check out pdf.js from https://github.com/mozilla/pdf.js to DRUPAL_HOME/sites/all/libraries/. OR download v0.1.0.zip from https://github.com/mozilla/pdf.js/tags and extract pdf.js directory to DRUPAL_HOME/sites/all/libraries/.

2. Make pdf.js file in the pdf.js/build directory by following the README. ((WARNING: pdf.js is a large file! Consider minifying it. Here is how to https://github.com/mozilla/pdf.js/issues/710#issuecomment-4080540)

3. Enable pdf module and create a file field and there are two option to display PDF file in the field display setting. (You need to use the latest pdf.js to use first page display.) 
